# wechat-app
一个基于技术栈：react 17 + TS 4.x + Taro 3.x + Taro UI 3.x + dva + less 的小程序项目
