module.exports = {
  env: {
    NODE_ENV: '"development"',
  },
  defineConstants: {
    API_BASE: JSON.stringify("ddd"),
  },
  mini: {},
  h5: {},
};
